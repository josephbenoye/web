function code(){
    var id = document.getElementById("code").value;
    var value=id.toUpperCase();
    document.getElementById("link").innerHTML="Here is the link : https://diksha.gov.in/get/dial/"+id;
    document.getElementById("dikshalink").href="https://diksha.gov.in/get/dial/"+value;
}